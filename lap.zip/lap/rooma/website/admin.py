
from django.contrib import admin
from website.models import *

# Register your models here.
admin.site.register(products) 
admin.site.register(bround)