import decimal
from email.policy import default
from tkinter import Place
from django.db import models
from django.forms import CharField, DateField, ImageField

# Create your models here.
class products(models.Model):
    name=models.CharField(max_length=100)
    prise=models.DecimalField(max_digits=100,decimal_places=2)
    img=models.ImageField()
    date=models.DateField()

    x= models.ForeignKey("bround", on_delete=models.CASCADE)
    def __str__(self):
        return self.name

class bround(models.Model):
    name=models.CharField(max_length=100)
    orign=models.CharField(max_length=100)
    imges=models.ImageField(default="{%static 'assest/img/map-image.png' %}")
    def __str__(self):
        return self.name

