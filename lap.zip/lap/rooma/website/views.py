from itertools import product
from re import template
from django.shortcuts import render
from website.models import *
# Create your views here.

def index(request):
    template='rooma/index.html'
    product=products.objects.all()
    brounds=bround.objects.all()
    context={"products":product,"brounds":brounds}
    return render(request,template,context)